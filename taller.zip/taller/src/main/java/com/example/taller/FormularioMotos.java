package com.example.taller;

import javafx.scene.control.*;
import javafx.scene.layout.GridPane;
import java.util.ArrayList;
import java.util.function.Consumer;

public class FormularioMotos {
private final ArrayList<Motocicleta>listaMotos;
private final Consumer<Void>actualizarTabla;
    private final TextField txtPlaca = new TextField();
    private final TextField txtMarca = new TextField();
    private final TextField txtAnio = new TextField();
    private final Button btnGuardar = new Button("Guardar Moto");
    private final Label lblMensaje = new Label("");

    public FormularioMotos (ArrayList<Motocicleta> listaMotos, Consumer<void> actualizarTabla){
        this.listaMotos=listaMotos;
        this.actualizarTabla=actualizarTabla;
        configurarLayout();
        configurarAcciones();
    }
    private void configurarLayout(){
        GridPane grid=new GridPane();
        grid.setHgap(10);
        grid.setVgap(10);
        grid.addRow(0, new Label("placa: "), txtPlaca);
        grid.addRow(1, new Label("marca: "),txtMarca);
        grid.addRow(2, new Label("modelo(año): "), txtAnio);
        grid.addRow(3, btnGuardar);
        grid.addRow(4, lblMensaje);
        txtPlaca.setPrefWidth(200);
        txtMarca.setPrefWidth(200);
        txtAnio.setPrefWidth(200);
    }
    private void configurarAcciones(){
        btnGuardar.setOnAction(e->{
            try {
                String placa=txtPlaca.getText().trim();
                String marca=txtMarca.getText().trim();
                int ano=Integer.parseInt(txtAnio.getText().trim());

                if(placa.isEmpty()||marca.isEmpty()){
                    lblMensaje.setText("Error, favor llenar todos los campos");
                    return;
                }
                Motocicleta nuevaMoto=new Motocicleta(placa,marca,ano);
                listaMotos.add(nuevaMoto);
                txtPlaca.clear();
                txtMarca.clear();
                txtAnio.clear();
                lblMensaje.setText("La moto ha sido guardada");
                actualizarTabla.accept(null);
            }catch(NumberFormatException ex){
                lblMensaje.setText("Error, el año debe ser entero");
            }
        });
    }
    public GridPane getVista(){
        return (GridPane) btnGuardar.getParent();
    }

}
