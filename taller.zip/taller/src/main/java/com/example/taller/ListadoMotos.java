package com.example.taller;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.cell.PropertyValueFactory;
import java.util.ArrayList;

public class ListadoMotos {
    private final ArrayList<Motocicleta>datosMotos;
    private final TableView<Motocicleta>tabla;
    private final ObservableList<Motocicleta> observableList;

    public ListadoMotos(ArrayList<Motocicleta>datosMotos){
        this.datosMotos=datosMotos;
        this.observableList =FXCollections.observableArrayList(datosMotos);
        this.tabla=crearTabla();
        actualizarTabla();
    }
    private TableView<Motocicleta>crearTabla(){

        TableView<Motocicleta>tv=new TableView<>();
        tv.setItems(observableList);

        TableColumn<Motocicleta, String> colPlaca=new TableColumn<>("Placa");
        colPlaca.setCellValueFactory(new PropertyValueFactory<>("placa"));

        TableColumn<Motocicleta, String> colMarca=new TableColumn<>("Marca");
        colMarca.setCellValueFactory(new PropertyValueFactory<>("marca"));

        TableColumn<Motocicleta, Integer> colAno=new TableColumn<>("Modelo(Año)");
        colAno.setCellValueFactory(new PropertyValueFactory<>("modeloAno"));

        tv.getColumns().addAll(colPlaca, colMarca, colAno);

        return tv;
    }
    public void actualizarTabla(){
        observableList.clear();
        observableList.addAll(datosMotos);
    }
    public TableView<Motocicleta>getVista(){
        return tabla;
    }
}
