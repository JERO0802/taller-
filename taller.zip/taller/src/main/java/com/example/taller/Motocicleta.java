package com.example.taller;

public class Motocicleta {
    private String placa;
    private String marca;
    private int modeloAno;

    public Motocicleta(String placa, String marca, int modeloAno){
        this.placa= new placa;
        this.marca=new marca;
        this.modeloAno=new modeloAno;
    }
    public String getPlaca(){
        return placa;
    }
    public void setPlaca(String placa){
        this.placa= placa;
    }

    public String getMarca() {
        return marca;
    }

    public void setMarca(String marca) {
        this.marca = marca;
    }

    public int getModeloAno() {
        return modeloAno;
    }

    public void setModeloAno(int modeloAno) {
        this.modeloAno = modeloAno;
    }
    @Override
    public String toString(){
        return "placa: " + placa + ", marca: " + marca + ", modelo (año): " + modeloAno;
    }
}
