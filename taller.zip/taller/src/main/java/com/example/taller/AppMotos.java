package com.example.taller;

import javafx.application.Application;
import javafx.scene.Scene;
import javafx.scene.control.Label;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;

import java.util.ArrayList;

public class AppMotos extends Application {

    private ArrayList<Motocicleta> listaMotos = new ArrayList<>();

    private FormularioMotos formulario;
    private ListadoMotos listado;

    @Override
    public void start(Stage primaryStage) {

        listado = new ListadoMotos(listaMotos);

        formulario = new FormularioMotos(listaMotos, listado::actualizarTabla);

        HBox dashboard = new HBox(20); // 20px de espaciado

        dashboard.getChildren().addAll(
                new VBox(10, new Label(" Formulario de Captura "), formulario.getVista()),
                new VBox(10, new Label(" Listado de Motocicletas "), listado.getVista())
        );

        Scene scene = new Scene(dashboard, 800, 400); // Ancho x Alto

        primaryStage.setTitle("Gestión de Motocicletas - Dashboard");
        primaryStage.setScene(scene);
        primaryStage.show();
    }

    public static void main(String[] args) {
        launch(args);
    }
}
